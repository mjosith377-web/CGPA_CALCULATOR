# Rental Rooms Management Website

A responsive starter based on the provided C program: 18 rooms; rooms 1–10 cost ₹5,200/month and rooms 11–18 cost ₹6,200/month; tenant details; payment month/reference; screenshot upload; pending/approved/rejected status; occupancy and property rules.

## Important limitations before using real data

This is a starter template, not a fully audited production system. It currently associates records with the currently signed-in Firebase UID. A tenant account cannot securely submit a payment into a separate owner's account using the supplied simple rules; that requires a proper verified owner UID and tenant-to-property authorization model. The owner email check in browser JavaScript only controls the UI and is NOT an authorization boundary. Do not use real tenant data or deploy publicly as a production service until you implement server-enforced owner roles and rules.

For a true owner + tenant portal, recommended production architecture:
- Owner UID stored in trusted configuration/claims, never trusted from browser-submitted data.
- Tenant identities mapped to room/lease records by an owner-controlled workflow.
- Rules restrict tenants to their own profile and payment submissions, and restrict approval/rejection to the owner.
- Storage rules allow only authorized tenant upload and owner read.
- Owner-only approval is best implemented using custom claims or a trusted backend/Cloud Function.

## 1. Firebase setup

1. Open https://console.firebase.google.com/ and select your project.
2. Project settings → General → Your apps → register a Web app (`</>`).
3. Copy the Firebase web config into `firebase-config.js`.
4. Set `OWNER_EMAIL` in that file to the owner email. This is only a UI label, not security.
5. Authentication → Sign-in method → enable Email/Password.
6. Firestore Database → create database if needed; publish `firestore.rules`.
7. Storage → Get started if available; publish `storage.rules`. Firebase Storage availability and billing requirements can vary by project and current Firebase plan.
8. Authentication → Settings → Authorized domains: add your GitHub Pages domain and later your custom domain.

## 2. GitHub Pages (free static hosting)

1. Create a GitHub repository named `rental-rooms-management-website`.
2. Upload the files in this folder to the repository root.
3. Repository Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.
4. Wait for GitHub Pages to provide the website URL.
5. Add the published domain to Firebase Authentication authorized domains.

A custom domain registration usually costs money even if hosting is free. Configure it in repository Settings → Pages and follow the DNS records shown by GitHub.

## 3. Test with fake data only

Test email sign-in, room display, tenant registration, and payment upload with non-real data. If you see “Missing or insufficient permissions,” review the rules. Do not make rules public to fix errors.

## Notes

- The site uploads payment proof images to Firebase Storage; it does not verify bank transactions.
- Room rent amounts are hard-coded to match the supplied C program.
- This starter does not yet include tenant self-service login securely mapped to a lease, rent due calculations, editing tenants, exports, automated backups, or production role provisioning.
- Do not put passwords, service-account keys, or private credentials in GitHub.
