// Copy this configuration from Firebase Console > Project settings > Your apps > Web app.
// Firebase web config is intended for client-side use. Never place service-account keys here.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

// Set this to your OWNER email before deployment.
// The first owner account must be created using that email. Do not allow public registration after setup.
export const OWNER_EMAIL = "owner@example.com";
